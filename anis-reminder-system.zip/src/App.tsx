import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { useEffect, useState } from 'react';
import { db, auth, storage } from './firebase';

// Pages
import LoginPage from './pages/LoginPage';
import DashboardLayout from './components/DashboardLayout';
import CustomersPage from './pages/CustomersPage';
import VehiclesPage from './pages/VehiclesPage';
import PoliciesPage from './pages/PoliciesPage';
import RemindersPage from './pages/RemindersPage';
import ReportsPage from './pages/ReportsPage';
import QRRegistrationPage from './pages/QRRegistrationPage';
import OfficesPage from './pages/OfficesPage';

export default function App() {
  // --- DEVELOPMENT BYPASS ---
  // Set a mock admin user for development
  const [user, setUser] = useState<any>({
    email: 'ahmedmsery0@gmail.com',
    displayName: 'Dev Admin',
    uid: 'dev-admin-uid'
  });
  const [loading, setLoading] = useState(false);

  /* Temporarily commented out for development bypass
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return unsubscribe;
  }, []);
  */
  // ---------------------------

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-neutral-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  const isAdmin = user?.email === 'ahmedmsery0@gmail.com';

  return (
    <Router>
      <Routes>
        {/* Public Route for QR Registration */}
        <Route path="/register/:officeId" element={<QRRegistrationPage />} />
        
        {/* Auth Route */}
        <Route path="/login" element={user && isAdmin ? <Navigate to="/dashboard" /> : <LoginPage />} />

        {/* Protected Dashboard Routes */}
        <Route path="/dashboard" element={user && isAdmin ? <DashboardLayout /> : <Navigate to="/login" />}>
          <Route index element={<Navigate to="customers" />} />
          <Route path="customers" element={<CustomersPage />} />
          <Route path="vehicles" element={<VehiclesPage />} />
          <Route path="policies" element={<PoliciesPage />} />
          <Route path="reminders" element={<RemindersPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="offices" element={<OfficesPage />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/dashboard" />} />
      </Routes>
    </Router>
  );
}
