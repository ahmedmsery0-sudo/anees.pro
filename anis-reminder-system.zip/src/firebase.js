import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDDK7d8UvvFhRDYMKwcc_JOyZdUDP406NQ",
  authDomain: "insurance-system-c2460.firebaseapp.com",
  projectId: "insurance-system-c2460",
  storageBucket: "insurance-system-c2460.firebasestorage.app",
  messagingSenderId: "321650509049",
  appId: "1:321650509049:web:2c4bedae1b8d65fdf40e28"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
