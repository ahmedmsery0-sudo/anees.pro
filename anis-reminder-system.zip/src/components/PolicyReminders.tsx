import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, Timestamp, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { AlertCircle, CheckCircle2, MessageCircle, Clock, X, Calendar } from 'lucide-react';
import { cn } from '../lib/utils';
import { format, differenceInDays } from 'date-fns';

interface Policy {
  id: string;
  vehicle_id: string;
  customer_name: string;
  plate_number: string;
  expiry_date: any;
  status: string;
  type: string;
  customer_phone?: string;
}

export default function PolicyReminders({ onClose }: { onClose: () => void }) {
  const [reminders, setReminders] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'policies'), where('status', '==', 'active'));
    
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const allPolicies = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      
      const expiringSoon = allPolicies.filter(p => {
        if (!p.expiry_date) return false;
        const date = p.expiry_date.toDate ? p.expiry_date.toDate() : new Date(p.expiry_date);
        const daysLeft = differenceInDays(date, new Date());
        return daysLeft <= 10 && daysLeft >= 0;
      });

      // Fetch customer and vehicle info for each policy
      const enrichedReminders = await Promise.all(expiringSoon.map(async (p) => {
        try {
          const vehicleDoc = await getDocs(query(collection(db, 'vehicles'), where('__name__', '==', p.vehicle_id)));
          if (!vehicleDoc.empty) {
            const vehicleData = vehicleDoc.docs[0].data();
            const customerDoc = await getDocs(query(collection(db, 'customers'), where('__name__', '==', vehicleData.customer_id)));
            if (!customerDoc.empty) {
              const customerData = customerDoc.docs[0].data();
              return {
                ...p,
                customer_name: customerData.name,
                customer_phone: customerData.whatsapp || customerData.phone,
                plate_number: vehicleData.plate_number
              };
            }
          }
        } catch (err) {
          console.error('Error enriching policy:', err);
        }
        return p;
      }));

      setReminders(enrichedReminders);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const sendWhatsAppReminder = (policy: Policy) => {
    const customerWhatsApp = policy.customer_phone || '';
    const formattedCustomerNum = customerWhatsApp.startsWith('00') ? customerWhatsApp : `00218${customerWhatsApp.replace(/^0/, '')}`;
    const date = format(policy.expiry_date.toDate ? policy.expiry_date.toDate() : new Date(policy.expiry_date), 'MMM dd, yyyy');
    
    // 1. Message for Customer
    const customerMessage = `Reminder for ${policy.customer_name}: Your vehicle (${policy.plate_number}) insurance policy is expiring on ${date}. Please renew it soon.`;
    const customerUrl = `https://wa.me/${formattedCustomerNum}?text=${encodeURIComponent(customerMessage)}`;
    window.open(customerUrl, '_blank');

    // 2. Message for Admin
    const adminNum = "00218911288166";
    const adminMessage = `اسم العميل: ${policy.customer_name}\nرقم الواتساب: ${customerWhatsApp}\nنوع الوثيقة: Insurance Policy\nستنتهي بعد 10 أيام (${date})`;
    const adminUrl = `https://wa.me/${adminNum}?text=${encodeURIComponent(adminMessage)}`;
    
    setTimeout(() => {
      window.open(adminUrl, '_blank');
    }, 1000);
  };

  const handleUpdateStatus = async (policyId: string, newStatus: string) => {
    if (!policyId) return;
    try {
      await updateDoc(doc(db, 'policies', policyId), {
        status: newStatus
      });
    } catch (error) {
      console.error('Error updating policy status:', error);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl max-h-[80vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-100 text-red-600 rounded-xl">
              <AlertCircle size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-neutral-900">Policy Reminders</h2>
              <p className="text-neutral-500 text-sm">Policies expiring within the next 10 days.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-neutral-200 rounded-full transition-all">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {loading ? (
            <div className="text-center py-10 text-neutral-400">Loading reminders...</div>
          ) : reminders.length === 0 ? (
            <div className="text-center py-10 text-neutral-400 italic">No policies expiring soon.</div>
          ) : (
            reminders.map(policy => {
              const date = policy.expiry_date.toDate ? policy.expiry_date.toDate() : new Date(policy.expiry_date);
              const daysLeft = differenceInDays(date, new Date());

              return (
                <div key={policy.id} className="p-4 bg-white border border-neutral-200 rounded-2xl shadow-sm flex items-center justify-between group hover:border-primary/30 transition-all">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center font-bold",
                      daysLeft <= 3 ? "bg-red-100 text-red-600" : "bg-yellow-100 text-yellow-600"
                    )}>
                      {daysLeft}d
                    </div>
                    <div>
                      <h3 className="font-bold text-neutral-900">{policy.customer_name || 'Unknown Customer'}</h3>
                      <p className="text-xs text-neutral-500">{policy.plate_number ? `Vehicle: ${policy.plate_number}` : `Policy #${policy.id.slice(0, 8)}`}</p>
                      <p className="text-[10px] font-bold text-red-500 uppercase mt-1">Expiring on {format(date, 'MMM dd, yyyy')}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => sendWhatsAppReminder(policy)}
                      className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-all"
                      title="Send WhatsApp Reminder"
                    >
                      <MessageCircle size={18} />
                    </button>
                    <button 
                      onClick={() => handleUpdateStatus(policy.id, 'renewed')}
                      className="px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-xs font-bold hover:bg-primary/20 transition-all"
                    >
                      Renewed
                    </button>
                    <button 
                      onClick={() => handleUpdateStatus(policy.id, 'expired')}
                      className="px-3 py-1.5 bg-neutral-50 text-neutral-600 rounded-lg text-xs font-bold hover:bg-neutral-100 transition-all"
                    >
                      Expired
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
