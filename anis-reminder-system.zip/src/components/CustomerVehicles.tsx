import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Car, Calendar, AlertCircle, CheckCircle2, MessageCircle, Clock, Image as ImageIcon } from 'lucide-react';
import { cn } from '../lib/utils';
import { format, differenceInDays, isAfter, addDays } from 'date-fns';
import VehicleDocumentManager from './VehicleDocumentManager';

interface Vehicle {
  id: string;
  customer_id: string;
  car_type: string;
  brand: string;
  model: string;
  year: string;
  plate_number: string;
  chassis_number: string;
  insurance_expiry: any;
  stamp_expiry: any;
  inspection_expiry: any;
  insurance_image_url?: string;
  stamp_image_url?: string;
  inspection_image_url?: string;
  whatsapp_status?: { [key: string]: 'sent' | 'pending' };
}

export default function CustomerVehicles({ customerId, customerName }: { customerId: string, customerName: string }) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'vehicles'), where('customer_id', '==', customerId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Vehicle));
      setVehicles(data);
      setLoading(false);
    });
    return unsubscribe;
  }, [customerId]);

  const checkExpiry = (expiryDate: any) => {
    if (!expiryDate) return { isNear: false, daysLeft: 0 };
    const date = expiryDate.toDate ? expiryDate.toDate() : new Date(expiryDate);
    const daysLeft = differenceInDays(date, new Date());
    return { isNear: daysLeft <= 7 && daysLeft >= 0, daysLeft };
  };

  const sendWhatsAppReminder = async (vehicle: Vehicle, type: string, expiryDate: any) => {
    if (!customerId || !vehicle.id) return;
    try {
      // Fetch customer data to get the correct WhatsApp number
      const customerDoc = await getDoc(doc(db, 'customers', customerId));
      if (!customerDoc.exists()) return;
      const customerData = customerDoc.data();
      const customerWhatsApp = customerData.whatsapp || customerData.phone || '';
      const formattedCustomerNum = customerWhatsApp.startsWith('00') ? customerWhatsApp : `00218${customerWhatsApp.replace(/^0/, '')}`;

      const date = format(expiryDate.toDate ? expiryDate.toDate() : new Date(expiryDate), 'MMM dd, yyyy');
      
      // 1. Message for Customer
      const customerMessage = `مرحباً ${customerName}، نود تذكيركم بأن وثيقة (${type}) لسيارتكم (${vehicle.brand} ${vehicle.plate_number}) ستنتهي بتاريخ ${date}. هل ترغبون في التجديد؟`;
      const customerUrl = `https://wa.me/${formattedCustomerNum}?text=${encodeURIComponent(customerMessage)}`;
      window.open(customerUrl, '_blank');

      // 2. Message for Admin
      const adminNum = "00218911288166";
      const createdAt = customerData.created_at?.toDate ? format(customerData.created_at.toDate(), 'yyyy-MM-dd') : 'N/A';
      const adminMessage = `اسم العميل: ${customerName}\nتاريخ التسجيل: ${createdAt}\nرقم الواتساب: ${customerWhatsApp}\nنوع الوثيقة: ${type}\nستنتهي بعد 7 أيام (${date})`;
      const adminUrl = `https://wa.me/${adminNum}?text=${encodeURIComponent(adminMessage)}`;
      
      setTimeout(() => {
        window.open(adminUrl, '_blank');
      }, 1000);

      // Update WhatsApp status in Firestore
      const vehicleRef = doc(db, 'vehicles', vehicle.id);
      const currentStatus = vehicle.whatsapp_status || {};
      await updateDoc(vehicleRef, {
        whatsapp_status: { ...currentStatus, [type]: 'sent' }
      });
    } catch (error) {
      console.error('Error sending WhatsApp reminder:', error);
    }
  };

  if (loading) return <div className="text-center py-10 text-neutral-400">Loading vehicles...</div>;
  if (vehicles.length === 0) return <div className="text-center py-10 text-neutral-400 italic">No vehicles found.</div>;

  return (
    <div className="grid grid-cols-1 gap-6">
      {vehicles.map(vehicle => (
        <div key={vehicle.id} className="bg-white border border-neutral-200 rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition-all">
          <div className="p-6 bg-neutral-50 border-b border-neutral-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                <Car size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-neutral-900">{vehicle.brand} {vehicle.model} ({vehicle.year})</h3>
                <p className="text-xs text-neutral-500 font-bold uppercase tracking-wider">{vehicle.plate_number} • {vehicle.car_type}</p>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-8">
            {/* Expiry Dates Section */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { label: 'Insurance', key: 'insurance', date: vehicle.insurance_expiry },
                { label: 'Stamp', key: 'stamp', date: vehicle.stamp_expiry },
                { label: 'Inspection', key: 'inspection', date: vehicle.inspection_expiry }
              ].map(item => {
                const { isNear, daysLeft } = checkExpiry(item.date);
                const status = vehicle.whatsapp_status?.[item.key] || 'pending';

                return (
                  <div key={item.key} className={cn(
                    "p-4 rounded-2xl border-2 transition-all flex flex-col gap-3",
                    isNear ? "border-red-200 bg-red-50" : "border-neutral-100 bg-neutral-50"
                  )}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">{item.label} Expiry</span>
                      {isNear && <AlertCircle className="text-red-500" size={14} />}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Calendar size={16} className={isNear ? "text-red-500" : "text-neutral-400"} />
                      <span className={cn("text-sm font-bold", isNear ? "text-red-700" : "text-neutral-900")}>
                        {item.date ? format(item.date.toDate ? item.date.toDate() : new Date(item.date), 'MMM dd, yyyy') : 'Not Set'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-neutral-200/50 mt-auto">
                      <div className="flex items-center gap-1">
                        <div className={cn("w-2 h-2 rounded-full", status === 'sent' ? "bg-green-500" : "bg-yellow-500")} />
                        <span className="text-[10px] font-bold text-neutral-500 uppercase">{status}</span>
                      </div>
                      <button 
                        onClick={() => sendWhatsAppReminder(vehicle, item.key, item.date)}
                        className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-all"
                        title="Send WhatsApp Reminder"
                      >
                        <MessageCircle size={16} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Document Uploads Section */}
            <div className="pt-6 border-t border-neutral-100">
              <VehicleDocumentManager 
                vehicleId={vehicle.id} 
                initialData={{
                  insurance_image_url: vehicle.insurance_image_url,
                  stamp_image_url: vehicle.stamp_image_url,
                  inspection_image_url: vehicle.inspection_image_url
                }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
