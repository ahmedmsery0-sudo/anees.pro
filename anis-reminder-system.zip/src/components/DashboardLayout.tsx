import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Car, 
  FileText, 
  Bell, 
  BarChart3, 
  LogOut, 
  Menu, 
  X,
  Building2
} from 'lucide-react';
import { useState } from 'react';
import { db, auth, storage } from '../firebase';
import { signOut } from 'firebase/auth';
import { cn } from '../lib/utils';

const navItems = [
  { name: 'Customers', path: '/dashboard/customers', icon: Users },
  { name: 'Vehicles', path: '/dashboard/vehicles', icon: Car },
  { name: 'Policies', path: '/dashboard/policies', icon: FileText },
  { name: 'Reminders', path: '/dashboard/reminders', icon: Bell },
  { name: 'Reports', path: '/dashboard/reports', icon: BarChart3 },
  { name: 'Offices', path: '/dashboard/offices', icon: Building2 },
];

export default function DashboardLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-neutral-50 font-sans">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 w-64 bg-white border-r border-neutral-200 z-50 transition-transform lg:relative lg:translate-x-0",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-neutral-100">
            <h1 className="text-xl font-bold text-primary tracking-tight italic serif">
              Anis Reminder
            </h1>
            <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">
              Admin Dashboard
            </p>
          </div>

          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                    isActive 
                      ? "bg-primary text-white shadow-lg shadow-primary/20" 
                      : "text-neutral-600 hover:bg-neutral-100"
                  )}
                  onClick={() => setIsSidebarOpen(false)}
                >
                  <Icon size={20} />
                  <span className="font-medium">{item.name}</span>
                </Link>
              );
            })}
          </nav>

          <div className="p-4 border-t border-neutral-100">
            <button
              onClick={handleLogout}
              className="flex items-center gap-3 w-full px-4 py-3 text-neutral-600 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all duration-200"
            >
              <LogOut size={20} />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-neutral-200 flex items-center justify-between px-6 lg:px-10">
          <button 
            className="lg:hidden p-2 text-neutral-600 hover:bg-neutral-100 rounded-lg"
            onClick={() => setIsSidebarOpen(true)}
          >
            <Menu size={24} />
          </button>
          
          <div className="flex items-center gap-4 ml-auto">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold text-neutral-900">Ahmed M. Sery</p>
              <p className="text-xs text-neutral-500">System Administrator</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              AM
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-10">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
