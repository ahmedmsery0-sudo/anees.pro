import React, { useState, useEffect } from 'react';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { doc, updateDoc } from 'firebase/firestore';
import { db, storage } from '../firebase';
import { 
  Upload, 
  CheckCircle2, 
  Loader2, 
  Image as ImageIcon, 
  X, 
  Eye, 
  AlertCircle,
  Camera
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface VehicleDocumentManagerProps {
  vehicleId: string;
  initialData?: {
    insurance_image_url?: string;
    stamp_image_url?: string;
    inspection_image_url?: string;
  };
  onUpdate?: (data: any) => void;
}

type DocumentType = 'insurance' | 'stamp' | 'inspection';

interface UploadState {
  uploading: boolean;
  progress: number;
  error: string | null;
  success: boolean;
}

export default function VehicleDocumentManager({ vehicleId, initialData, onUpdate }: VehicleDocumentManagerProps) {
  const [docs, setDocs] = useState({
    insurance: initialData?.insurance_image_url || null,
    stamp: initialData?.stamp_image_url || null,
    inspection: initialData?.inspection_image_url || null
  });

  const [uploadStates, setUploadStates] = useState<Record<DocumentType, UploadState>>({
    insurance: { uploading: false, progress: 0, error: null, success: false },
    stamp: { uploading: false, progress: 0, error: null, success: false },
    inspection: { uploading: false, progress: 0, error: null, success: false }
  });

  const [viewImage, setViewImage] = useState<string | null>(null);

  const handleUpload = async (file: File, type: DocumentType) => {
    if (!vehicleId) {
      setUploadStates(prev => ({
        ...prev,
        [type]: { ...prev[type], error: 'Vehicle ID is missing' }
      }));
      return;
    }

    setUploadStates(prev => ({
      ...prev,
      [type]: { uploading: true, progress: 0, error: null, success: false }
    }));

    try {
      // Folder structure: type/
      // Filename format: <vehicleId>_<originalFileName>
      const fileName = `${vehicleId}_${file.name}`;
      const storageRef = ref(storage, `${type}/${fileName}`);
      
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on('state_changed', 
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setUploadStates(prev => ({
            ...prev,
            [type]: { ...prev[type], progress }
          }));
        }, 
        (error) => {
          console.error(`Upload error for ${type}:`, error);
          setUploadStates(prev => ({
            ...prev,
            [type]: { uploading: false, progress: 0, error: 'Upload failed. Please try again.', success: false }
          }));
        }, 
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          
          // Update Firestore
          const vehicleRef = doc(db, 'vehicles', vehicleId);
          await updateDoc(vehicleRef, {
            [`${type}_image_url`]: downloadURL
          });

          setDocs(prev => ({ ...prev, [type]: downloadURL }));
          setUploadStates(prev => ({
            ...prev,
            [type]: { uploading: false, progress: 100, error: null, success: true }
          }));

          if (onUpdate) {
            onUpdate({ [`${type}_image_url`]: downloadURL });
          }

          // Reset success message after 3 seconds
          setTimeout(() => {
            setUploadStates(prev => ({
              ...prev,
              [type]: { ...prev[type], success: false }
            }));
          }, 3000);
        }
      );
    } catch (error) {
      console.error(`Error in ${type} upload:`, error);
      setUploadStates(prev => ({
        ...prev,
        [type]: { uploading: false, progress: 0, error: 'An unexpected error occurred.', success: false }
      }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: DocumentType) => {
    const file = e.target.files?.[0];
    if (file) {
      handleUpload(file, type);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {(['insurance', 'stamp', 'inspection'] as DocumentType[]).map((type) => (
          <div key={type} className="flex flex-col gap-2">
            <div className="flex items-center justify-between px-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">
                {type.charAt(0).toUpperCase() + type.slice(1)} Document
              </label>
              {uploadStates[type].success && (
                <motion.span 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-[10px] font-bold text-green-500 uppercase"
                >
                  Saved!
                </motion.span>
              )}
            </div>

            <div className="relative group">
              {/* Hidden File Input */}
              <input 
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(e) => handleFileChange(e, type)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                disabled={uploadStates[type].uploading}
              />

              {/* Upload UI */}
              <div className={cn(
                "w-full h-32 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-all overflow-hidden relative",
                docs[type] ? "border-green-200 bg-green-50" : "border-neutral-200 bg-neutral-50 group-hover:border-primary/30",
                uploadStates[type].error ? "border-red-200 bg-red-50" : ""
              )}>
                {docs[type] ? (
                  <div className="relative w-full h-full group/img">
                    <img 
                      src={docs[type]!} 
                      alt={type} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center gap-3">
                      <button 
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewImage(docs[type]);
                        }}
                        className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white transition-all z-20"
                      >
                        <Eye size={20} />
                      </button>
                      <div className="p-2 bg-white/20 rounded-full text-white">
                        <Upload size={20} />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2 p-4 text-center">
                    {uploadStates[type].uploading ? (
                      <div className="relative w-12 h-12 flex items-center justify-center">
                        <svg className="w-full h-full -rotate-90">
                          <circle
                            cx="24"
                            cy="24"
                            r="20"
                            stroke="currentColor"
                            strokeWidth="4"
                            fill="transparent"
                            className="text-neutral-200"
                          />
                          <circle
                            cx="24"
                            cy="24"
                            r="20"
                            stroke="currentColor"
                            strokeWidth="4"
                            fill="transparent"
                            strokeDasharray={125.6}
                            strokeDashoffset={125.6 - (125.6 * uploadStates[type].progress) / 100}
                            className="text-primary transition-all duration-300"
                          />
                        </svg>
                        <span className="absolute text-[10px] font-bold text-primary">
                          {Math.round(uploadStates[type].progress)}%
                        </span>
                      </div>
                    ) : (
                      <>
                        <div className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center text-neutral-400 group-hover:bg-primary/10 group-hover:text-primary transition-all">
                          <Camera size={20} />
                        </div>
                        <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-tight">
                          Click to upload or take photo
                        </p>
                      </>
                    )}
                  </div>
                )}

                {/* Error Message */}
                {uploadStates[type].error && (
                  <div className="absolute bottom-0 left-0 right-0 bg-red-500 text-white text-[8px] font-bold py-1 px-2 flex items-center gap-1">
                    <AlertCircle size={10} />
                    <span className="truncate">{uploadStates[type].error}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Full Size Image Viewer */}
      <AnimatePresence>
        {viewImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4 sm:p-10"
            onClick={() => setViewImage(null)}
          >
            <button 
              className="absolute top-6 right-6 text-white/50 hover:text-white transition-all"
              onClick={() => setViewImage(null)}
            >
              <X size={32} />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              src={viewImage} 
              alt="Full size" 
              className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
              onClick={(e) => e.stopPropagation()}
              referrerPolicy="no-referrer"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
