import React, { useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { collection, addDoc, serverTimestamp, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Upload, FileSpreadsheet, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';

export default function ExcelImport() {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setStatus({ type: null, message: '' });

    try {
      const reader = new FileReader();
      reader.onload = async (evt) => {
        try {
          const bstr = evt.target?.result;
          const wb = XLSX.read(bstr, { type: 'binary' });
          const wsname = wb.SheetNames[0];
          const ws = wb.Sheets[wsname];
          const data = XLSX.utils.sheet_to_json(ws);

          let importedCount = 0;

          for (const row of data as any[]) {
            const customerName = row['Customer Name'] || row['الاسم'];
            const phone = String(row['Phone'] || row['الهاتف'] || '');
            const city = row['City'] || row['المدينة'];
            const brand = row['Vehicle Brand'] || row['النوع'];
            const plate = String(row['Plate'] || row['رقم اللوحة'] || '');
            const chassis = String(row['Chassis'] || row['رقم الهيكل'] || '');
            const year = String(row['Year'] || row['السنة'] || '');
            
            if (!customerName || !phone) continue;

            // 1. Find or Create Customer
            let customerId = '';
            const q = query(collection(db, 'customers'), where('phone', '==', phone));
            const existingCustomer = await getDocs(q);
            
            if (!existingCustomer.empty) {
              customerId = existingCustomer.docs[0].id;
            } else {
              const customerRef = await addDoc(collection(db, 'customers'), {
                name: customerName,
                phone: phone,
                whatsapp: phone,
                city: city || 'Unknown',
                status: 'جديد',
                payment_status: 'unpaid',
                archived: false,
                created_at: serverTimestamp()
              });
              customerId = customerRef.id;
            }

            // Helper to parse Excel dates
            const parseExcelDate = (val: any) => {
              if (!val) return null;
              if (typeof val === 'number') {
                // Excel serial date
                return new Date((val - 25569) * 86400 * 1000);
              }
              const d = new Date(val);
              return isNaN(d.getTime()) ? null : d;
            };

            // 2. Create Vehicle
            await addDoc(collection(db, 'vehicles'), {
              customer_id: customerId,
              brand: brand || 'Unknown',
              model: row['Model'] || '',
              year: year,
              plate_number: plate,
              chassis_number: chassis,
              car_type: row['Car Type'] || 'Private',
              insurance_expiry: parseExcelDate(row['Insurance Expiry']),
              stamp_expiry: parseExcelDate(row['Stamp Expiry']),
              inspection_expiry: parseExcelDate(row['Inspection Expiry']),
              insurance_image_url: row['Insurance Image URL'] || '',
              stamp_image_url: row['Stamp Image URL'] || '',
              inspection_image_url: row['Inspection Image URL'] || '',
              created_at: serverTimestamp()
            });

            importedCount++;
          }

          setStatus({ type: 'success', message: `Successfully imported ${importedCount} records!` });
          if (fileInputRef.current) fileInputRef.current.value = '';
        } catch (err) {
          console.error('Error processing Excel data:', err);
          setStatus({ type: 'error', message: 'Failed to process Excel data. Check column names.' });
        }
      };
      reader.readAsBinaryString(file);
    } catch (err) {
      console.error('Error reading file:', err);
      setStatus({ type: 'error', message: 'Failed to read file.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <input
          type="file"
          accept=".xlsx, .xls"
          onChange={handleFileUpload}
          className="hidden"
          ref={fileInputRef}
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={loading}
          className={cn(
            "flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold shadow-lg shadow-green-200 hover:bg-green-700 transition-all disabled:opacity-50",
            loading && "animate-pulse"
          )}
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : <FileSpreadsheet size={20} />}
          <span>{loading ? 'Importing...' : 'Import from Excel'}</span>
        </button>
      </div>

      {status.type && (
        <div className={cn(
          "flex items-center gap-3 p-4 rounded-xl text-sm font-medium animate-in fade-in slide-in-from-top-2",
          status.type === 'success' ? "bg-green-50 text-green-700 border border-green-100" : "bg-red-50 text-red-700 border border-red-100"
        )}>
          {status.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{status.message}</span>
        </div>
      )}
    </div>
  );
}
