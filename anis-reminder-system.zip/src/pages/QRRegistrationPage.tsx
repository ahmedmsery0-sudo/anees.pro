import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, serverTimestamp, updateDoc, Timestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, auth, storage } from '../firebase';
import { 
  CheckCircle2, 
  Upload, 
  Car, 
  User, 
  Phone, 
  MapPin, 
  FileText, 
  AlertCircle,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { cn } from '../lib/utils';

export default function QRRegistrationPage() {
  const { officeId } = useParams();
  const [office, setOffice] = useState<any>(null);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    whatsapp: '',
    city: '',
    car_type: '',
    brand: '',
    model: '',
    year: '',
    plate_number: '',
    chassis_number: '',
    payment_option: 'cash'
  });

  const [files, setFiles] = useState<{ [key: string]: File | null }>({
    insurance: null,
    stamp: null,
    inspection: null
  });

  useEffect(() => {
    const fetchOffice = async () => {
      if (officeId) {
        const officeDoc = await getDoc(doc(db, 'offices', officeId));
        if (officeDoc.exists()) {
          setOffice(officeDoc.data());
          setFormData(prev => ({ ...prev, city: officeDoc.data().city }));
        }
      }
    };
    fetchOffice();
  }, [officeId]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: string) => {
    if (e.target.files?.[0]) {
      setFiles(prev => ({ ...prev, [type]: e.target.files![0] }));
    }
  };

  const uploadFile = async (file: File, type: string, vehicleId: string) => {
    // Requirements:
    // Folder structure: type/
    // Filename format: <vehicleId>_<originalFileName>
    const fileName = `${vehicleId}_${file.name}`;
    const storageRef = ref(storage, `${type}/${fileName}`);
    await uploadBytes(storageRef, file);
    return await getDownloadURL(storageRef);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (!files.insurance || !files.stamp || !files.inspection) {
      setError('Please upload all required documents (Insurance, Stamp, and Inspection).');
      setLoading(false);
      return;
    }

    try {
      // 1. Create Customer
      const customerRef = await addDoc(collection(db, 'customers'), {
        name: formData.name,
        phone: formData.phone,
        whatsapp: formData.whatsapp,
        city: formData.city,
        created_at: serverTimestamp(),
        archived: false,
        payment_status: formData.payment_option === 'electronic' ? 'paid' : 'unpaid',
        status: 'تم التواصل',
        customer_notes: `Registered via office: ${office?.office_name || 'Unknown'}`
      });

      // 2. Create Vehicle
      const vehicleRef = await addDoc(collection(db, 'vehicles'), {
        customer_id: customerRef.id,
        car_type: formData.car_type,
        brand: formData.brand,
        model: formData.model,
        year: formData.year,
        plate_number: formData.plate_number,
        chassis_number: formData.chassis_number,
        created_at: serverTimestamp()
      });

      // 3. Upload Images after vehicle creation to get vehicleId
      const insuranceUrl = files.insurance ? await uploadFile(files.insurance, 'insurance', vehicleRef.id) : '';
      const stampUrl = files.stamp ? await uploadFile(files.stamp, 'stamp', vehicleRef.id) : '';
      const inspectionUrl = files.inspection ? await uploadFile(files.inspection, 'inspection', vehicleRef.id) : '';

      // 4. Update Vehicle with URLs
      if (insuranceUrl || stampUrl || inspectionUrl) {
        await updateDoc(doc(db, 'vehicles', vehicleRef.id), {
          insurance_image_url: insuranceUrl,
          stamp_image_url: stampUrl,
          inspection_image_url: inspectionUrl
        });
      }

      // 5. Create Policy (Initial Placeholder)
      await addDoc(collection(db, 'policies'), {
        vehicle_id: vehicleRef.id,
        price: 0, // Admin will set this
        office_commission: 0,
        admin_profit: 0,
        expiry_date: serverTimestamp(), // Admin will set this
        status: 'active',
        payment_status: formData.payment_option === 'electronic' ? 'paid' : 'unpaid'
      });

      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || 'Failed to submit registration. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-10 text-center border border-neutral-100">
          <div className="w-20 h-20 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 size={48} />
          </div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight mb-4">Registration Successful!</h1>
          <p className="text-neutral-500 mb-8">Your information has been received. Our team will contact you shortly to finalize your policy.</p>
          <button 
            onClick={() => window.location.reload()}
            className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all"
          >
            Register Another Vehicle
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 p-6 sm:p-10">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight serif italic">Anis Reminder System</h1>
          {office && (
            <p className="text-neutral-500 mt-2 flex items-center justify-center gap-2">
              <MapPin size={16} />
              Welcome to {office.office_name} - {office.city}
            </p>
          )}
        </div>

        {/* Progress Bar */}
        <div className="flex items-center gap-4 mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex-1 flex items-center gap-2">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all",
                step >= s ? "bg-primary text-white" : "bg-neutral-200 text-neutral-500"
              )}>
                {s}
              </div>
              <div className={cn(
                "flex-1 h-1 rounded-full transition-all",
                step > s ? "bg-primary" : "bg-neutral-200"
              )} />
            </div>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-xl border border-neutral-100 overflow-hidden">
          <div className="p-8 sm:p-10">
            {error && (
              <div className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-xl flex items-center gap-3 text-sm mb-8">
                <AlertCircle size={18} />
                <span>{error}</span>
              </div>
            )}

            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h2 className="text-xl font-bold text-neutral-900 flex items-center gap-2">
                  <User className="text-primary" size={24} />
                  Personal Information
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <Input label="Full Name" name="name" value={formData.name} onChange={handleInputChange} required />
                  <Input label="Phone Number" name="phone" value={formData.phone} onChange={handleInputChange} required />
                  <Input label="WhatsApp Number" name="whatsapp" value={formData.whatsapp} onChange={handleInputChange} required />
                  <Input label="City" name="city" value={formData.city} onChange={handleInputChange} required />
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h2 className="text-xl font-bold text-neutral-900 flex items-center gap-2">
                  <Car className="text-primary" size={24} />
                  Vehicle Details
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <Input label="Car Type" name="car_type" value={formData.car_type} onChange={handleInputChange} required />
                  <Input label="Brand" name="brand" value={formData.brand} onChange={handleInputChange} required />
                  <Input label="Model" name="model" value={formData.model} onChange={handleInputChange} required />
                  <Input label="Year" name="year" value={formData.year} onChange={handleInputChange} required />
                  <Input label="Plate Number" name="plate_number" value={formData.plate_number} onChange={handleInputChange} required />
                  <Input label="Chassis Number" name="chassis_number" value={formData.chassis_number} onChange={handleInputChange} required />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h2 className="text-xl font-bold text-neutral-900 flex items-center gap-2">
                  <FileText className="text-primary" size={24} />
                  Documents & Payment
                </h2>
                <div className="space-y-4">
                  <FileInput label="Insurance Document" onChange={(e) => handleFileChange(e, 'insurance')} file={files.insurance} />
                  <FileInput label="Stamp Document" onChange={(e) => handleFileChange(e, 'stamp')} file={files.stamp} />
                  <FileInput label="Inspection Document" onChange={(e) => handleFileChange(e, 'inspection')} file={files.inspection} />
                </div>
                <div className="pt-6 border-t border-neutral-100">
                  <label className="text-sm font-semibold text-neutral-700 mb-3 block">Payment Option</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, payment_option: 'cash' }))}
                      className={cn(
                        "p-4 rounded-xl border-2 transition-all text-center",
                        formData.payment_option === 'cash' ? "border-primary bg-primary/5 text-primary" : "border-neutral-100 text-neutral-500"
                      )}
                    >
                      Cash
                    </button>
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, payment_option: 'electronic' }))}
                      className={cn(
                        "p-4 rounded-xl border-2 transition-all text-center",
                        formData.payment_option === 'electronic' ? "border-primary bg-primary/5 text-primary" : "border-neutral-100 text-neutral-500"
                      )}
                    >
                      Electronic
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-8 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between">
            {step > 1 ? (
              <button 
                type="button" 
                onClick={() => setStep(step - 1)}
                className="flex items-center gap-2 text-neutral-600 font-bold hover:text-neutral-900 transition-all"
              >
                <ChevronLeft size={20} />
                Back
              </button>
            ) : <div />}

            {step < 3 ? (
              <button 
                type="button" 
                onClick={() => setStep(step + 1)}
                className="flex items-center gap-2 bg-primary text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all"
              >
                Next Step
                <ChevronRight size={20} />
              </button>
            ) : (
              <button 
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 bg-primary text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all disabled:opacity-50"
              >
                {loading ? 'Submitting...' : 'Complete Registration'}
                {!loading && <CheckCircle2 size={20} />}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

function Input({ label, ...props }: any) {
  return (
    <div className="space-y-2">
      <label className="text-sm font-semibold text-neutral-700 ml-1">{label}</label>
      <input 
        className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
        {...props}
      />
    </div>
  );
}

function FileInput({ label, onChange, file }: any) {
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
      return () => URL.revokeObjectURL(url);
    } else {
      setPreview(null);
    }
  }, [file]);

  return (
    <div className="space-y-2">
      <label className="text-sm font-semibold text-neutral-700 ml-1">{label}</label>
      <div className="relative group">
        <input 
          type="file" 
          accept="image/*"
          capture="environment"
          onChange={onChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        <div className={cn(
          "w-full px-4 py-4 border-2 border-dashed rounded-2xl flex items-center justify-between transition-all overflow-hidden",
          file ? "border-green-200 bg-green-50" : "border-neutral-200 bg-neutral-50 group-hover:border-primary/30"
        )}>
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center overflow-hidden",
              file ? "bg-green-100 text-green-600" : "bg-neutral-100 text-neutral-400"
            )}>
              {preview ? (
                <img src={preview} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <Upload size={20} />
              )}
            </div>
            <div>
              <p className={cn("text-sm font-bold", file ? "text-green-700" : "text-neutral-600")}>
                {file ? file.name : 'Choose file or take photo'}
              </p>
              <p className="text-xs text-neutral-400">PNG, JPG up to 5MB</p>
            </div>
          </div>
          {file && <CheckCircle2 className="text-green-500" size={20} />}
        </div>
      </div>
    </div>
  );
}
