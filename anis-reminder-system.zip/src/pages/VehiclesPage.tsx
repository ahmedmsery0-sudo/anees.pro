import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db, auth, storage } from '../firebase';
import { 
  Search, 
  Car, 
  Eye, 
  Filter, 
  ChevronRight,
  User,
  Hash,
  Image as ImageIcon,
  X
} from 'lucide-react';
import { cn } from '../lib/utils';
import VehicleDocumentManager from '../components/VehicleDocumentManager';

interface Vehicle {
  id: string;
  customer_id: string;
  customer_name?: string;
  car_type: string;
  brand: string;
  model: string;
  year: string;
  plate_number: string;
  chassis_number: string;
  insurance_image_url?: string;
  stamp_image_url?: string;
  inspection_image_url?: string;
}

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'vehicles'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const vehicleData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Vehicle));
      
      // Fetch customer names for each vehicle
      const vehiclesWithNames = await Promise.all(vehicleData.map(async (v) => {
        if (!v.customer_id) return { ...v, customer_name: 'Unknown' };
        const customerDoc = await getDoc(doc(db, 'customers', v.customer_id));
        return { ...v, customer_name: customerDoc.exists() ? customerDoc.data().name : 'Unknown' };
      }));

      setVehicles(vehiclesWithNames);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const filteredVehicles = vehicles.filter(v => 
    v.brand.toLowerCase().includes(searchTerm.toLowerCase()) || 
    v.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.plate_number.includes(searchTerm) ||
    v.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Vehicles</h1>
          <p className="text-neutral-500 mt-1">Manage and view vehicle details and documents.</p>
        </div>
      </div>

      {/* Search Section */}
      <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
          <input
            type="text"
            placeholder="Search by brand, model, plate, or customer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
          />
        </div>
      </div>

      {/* Grid Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-20 text-neutral-400">Loading vehicles...</div>
        ) : filteredVehicles.length === 0 ? (
          <div className="col-span-full text-center py-20 text-neutral-400">No vehicles found.</div>
        ) : filteredVehicles.map((vehicle) => (
          <div key={vehicle.id} className="bg-white rounded-2xl border border-neutral-200 shadow-sm hover:shadow-md transition-all group p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <Car size={24} />
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => {
                    setSelectedVehicle(vehicle);
                    setIsDocModalOpen(true);
                  }}
                  className="p-2 text-neutral-400 hover:text-primary hover:bg-primary/5 rounded-lg transition-all"
                  title="Manage Documents"
                >
                  <ImageIcon size={18} />
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-bold text-neutral-900 leading-tight">
                  {vehicle.brand} {vehicle.model}
                </h3>
                <p className="text-sm text-neutral-500 mt-1 flex items-center gap-1">
                  <User size={14} />
                  <span>{vehicle.customer_name}</span>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-100">
                <div className="space-y-1">
                  <p className="text-[10px] uppercase tracking-wider font-bold text-neutral-400">Plate Number</p>
                  <p className="text-sm font-semibold text-neutral-700">{vehicle.plate_number}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] uppercase tracking-wider font-bold text-neutral-400">Year</p>
                  <p className="text-sm font-semibold text-neutral-700">{vehicle.year}</p>
                </div>
                <div className="space-y-1 col-span-2">
                  <p className="text-[10px] uppercase tracking-wider font-bold text-neutral-400">Chassis Number</p>
                  <p className="text-sm font-mono text-neutral-600 truncate">{vehicle.chassis_number}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-4">
                {vehicle.insurance_image_url && (
                  <div className="px-2 py-1 bg-neutral-100 rounded text-[10px] font-bold text-neutral-500 flex items-center gap-1">
                    <ImageIcon size={10} />
                    INSURANCE
                  </div>
                )}
                {vehicle.stamp_image_url && (
                  <div className="px-2 py-1 bg-neutral-100 rounded text-[10px] font-bold text-neutral-500 flex items-center gap-1">
                    <ImageIcon size={10} />
                    STAMP
                  </div>
                )}
                {vehicle.inspection_image_url && (
                  <div className="px-2 py-1 bg-neutral-100 rounded text-[10px] font-bold text-neutral-500 flex items-center gap-1">
                    <ImageIcon size={10} />
                    INSPECTION
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Document Management Modal */}
      {isDocModalOpen && selectedVehicle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col">
            <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/50">
              <div>
                <h2 className="text-2xl font-bold text-neutral-900">Vehicle Documents</h2>
                <p className="text-neutral-500 text-sm">
                  {selectedVehicle.brand} {selectedVehicle.model} • {selectedVehicle.plate_number}
                </p>
              </div>
              <button 
                onClick={() => {
                  setIsDocModalOpen(false);
                  setSelectedVehicle(null);
                }}
                className="p-2 hover:bg-neutral-200 rounded-full transition-all"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6">
              <VehicleDocumentManager 
                vehicleId={selectedVehicle.id}
                initialData={{
                  insurance_image_url: selectedVehicle.insurance_image_url,
                  stamp_image_url: selectedVehicle.stamp_image_url,
                  inspection_image_url: selectedVehicle.inspection_image_url
                }}
                onUpdate={() => {
                  // The onSnapshot listener in useEffect will handle the update automatically
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
