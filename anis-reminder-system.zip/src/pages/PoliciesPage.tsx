import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, getDoc, where } from 'firebase/firestore';
import { db, auth, storage } from '../firebase';
import { 
  Search, 
  FileText, 
  Eye, 
  Filter, 
  ChevronRight,
  User,
  Calendar,
  DollarSign,
  TrendingUp,
  Clock,
  Send,
  Car
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format, isAfter, addDays, differenceInDays } from 'date-fns';

interface Policy {
  id: string;
  vehicle_id: string;
  customer_name?: string;
  vehicle_info?: string;
  price: number;
  office_commission: number;
  admin_profit: number;
  expiry_date: any;
  status: 'active' | 'expired' | 'renewed';
  payment_status: 'paid' | 'unpaid';
}

export default function PoliciesPage() {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterExpiry, setFilterExpiry] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'policies'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const policyData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Policy));
      
      // Fetch vehicle and customer info for each policy
      const policiesWithInfo = await Promise.all(policyData.map(async (p) => {
        if (!p.vehicle_id) return { ...p, customer_name: 'Unknown', vehicle_info: 'Unknown' };
        const vehicleDoc = await getDoc(doc(db, 'vehicles', p.vehicle_id));
        if (vehicleDoc.exists()) {
          const vData = vehicleDoc.data();
          if (vData.customer_id) {
            const customerDoc = await getDoc(doc(db, 'customers', vData.customer_id));
            return { 
              ...p, 
              customer_name: customerDoc.exists() ? customerDoc.data().name : 'Unknown',
              vehicle_info: `${vData.brand} ${vData.model} (${vData.plate_number})`
            };
          }
        }
        return { ...p, customer_name: 'Unknown', vehicle_info: 'Unknown' };
      }));

      setPolicies(policiesWithInfo);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const filteredPolicies = policies.filter(p => {
    const matchesSearch = p.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         p.vehicle_info?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterExpiry) {
      const expiryDate = p.expiry_date.toDate();
      const inNext10Days = isAfter(expiryDate, new Date()) && 
                          isAfter(addDays(new Date(), 10), expiryDate);
      return matchesSearch && inNext10Days;
    }
    return matchesSearch;
  });

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Policies</h1>
          <p className="text-neutral-500 mt-1">Track insurance policies, profits, and expirations.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setFilterExpiry(!filterExpiry)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 border rounded-xl transition-all font-medium",
              filterExpiry 
                ? "bg-primary/10 border-primary text-primary" 
                : "bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50"
            )}
          >
            <Clock size={18} />
            <span>Expiring Soon (10d)</span>
          </button>
        </div>
      </div>

      {/* Search Section */}
      <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
          <input
            type="text"
            placeholder="Search by customer or vehicle..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
          />
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-neutral-50 border-bottom border-neutral-200">
                <th className="px-6 py-4 text-xs font-bold text-neutral-500 uppercase tracking-wider">Customer / Vehicle</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-500 uppercase tracking-wider">Financials</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-500 uppercase tracking-wider">Expiry Date</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-neutral-400">Loading policies...</td>
                </tr>
              ) : filteredPolicies.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-neutral-400">No policies found.</td>
                </tr>
              ) : filteredPolicies.map((policy) => {
                const expiryDate = policy.expiry_date.toDate();
                const daysLeft = differenceInDays(expiryDate, new Date());
                const isExpiringSoon = daysLeft <= 10 && daysLeft >= 0;

                return (
                  <tr key={policy.id} className="hover:bg-neutral-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        <p className="font-semibold text-neutral-900">{policy.customer_name}</p>
                        <p className="text-xs text-neutral-500 flex items-center gap-1">
                          <Car size={12} />
                          {policy.vehicle_info}
                        </p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm font-bold text-neutral-900">
                          <DollarSign size={14} className="text-neutral-400" />
                          <span>{policy.price.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] font-bold text-green-600 uppercase tracking-wider">
                          <TrendingUp size={10} />
                          <span>Profit: {policy.admin_profit.toLocaleString()}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm text-neutral-700">
                          <Calendar size={14} className="text-neutral-400" />
                          <span>{format(expiryDate, 'MMM dd, yyyy')}</span>
                        </div>
                        {isExpiringSoon && (
                          <span className="text-[10px] font-bold text-red-600 uppercase tracking-wider">
                            {daysLeft} days left
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-2">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider w-fit",
                          policy.status === 'active' ? "bg-green-100 text-green-700" :
                          policy.status === 'expired' ? "bg-red-100 text-red-700" :
                          "bg-blue-100 text-blue-700"
                        )}>
                          {policy.status}
                        </span>
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider w-fit",
                          policy.payment_status === 'paid' ? "bg-neutral-100 text-neutral-700" : "bg-red-50 text-red-600"
                        )}>
                          {policy.payment_status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button className="p-2 text-neutral-400 hover:text-primary hover:bg-primary/5 rounded-lg transition-all" title="Send Reminder">
                          <Send size={18} />
                        </button>
                        <button className="p-2 text-neutral-400 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-all">
                          <ChevronRight size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
