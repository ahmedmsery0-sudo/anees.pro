import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db, auth, storage } from '../firebase';
import { 
  Building2, 
  Plus, 
  MapPin, 
  Calendar, 
  QrCode, 
  Trash2, 
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';

interface Office {
  id: string;
  office_name: string;
  city: string;
  subscription_expiry: any;
  QR_code_url?: string;
}

export default function OfficesPage() {
  const [offices, setOffices] = useState<Office[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newOffice, setNewOffice] = useState({ name: '', city: '', expiry: '' });
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'offices'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Office));
      setOffices(data);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleAddOffice = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'offices'), {
        office_name: newOffice.name,
        city: newOffice.city,
        subscription_expiry: new Date(newOffice.expiry),
        created_at: serverTimestamp()
      });
      setIsAddModalOpen(false);
      setNewOffice({ name: '', city: '', expiry: '' });
    } catch (error) {
      console.error('Error adding office:', error);
    }
  };

  const copyRegistrationLink = (id: string) => {
    const url = `${window.location.origin}/register/${id}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Offices</h1>
          <p className="text-neutral-500 mt-1">Manage partner offices and registration links.</p>
        </div>
        <button 
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-xl shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all font-medium"
        >
          <Plus size={18} />
          <span>Add Office</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-20 text-neutral-400">Loading offices...</div>
        ) : offices.length === 0 ? (
          <div className="col-span-full text-center py-20 text-neutral-400">No offices found. Add one to get started.</div>
        ) : offices.map((office) => (
          <div key={office.id} className="bg-white rounded-3xl border border-neutral-200 shadow-sm p-6 hover:shadow-md transition-all group">
            <div className="flex items-start justify-between mb-6">
              <div className="w-12 h-12 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center">
                <Building2 size={24} />
              </div>
              <button 
                onClick={() => {
                  if (office.id && window.confirm('Are you sure you want to delete this office?')) {
                    deleteDoc(doc(db, 'offices', office.id));
                  }
                }}
                className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
              >
                <Trash2 size={18} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-bold text-neutral-900">{office.office_name}</h3>
                <p className="text-sm text-neutral-500 flex items-center gap-1 mt-1">
                  <MapPin size={14} />
                  {office.city}
                </p>
              </div>

              <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-100">
                <p className="text-[10px] uppercase tracking-wider font-bold text-neutral-400 mb-1">Subscription Expiry</p>
                <p className="text-sm font-semibold text-neutral-700 flex items-center gap-2">
                  <Calendar size={14} className="text-neutral-400" />
                  {format(office.subscription_expiry.toDate(), 'MMM dd, yyyy')}
                </p>
              </div>

              <div className="pt-4 border-t border-neutral-100 flex gap-2">
                <button 
                  onClick={() => copyRegistrationLink(office.id)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-neutral-800 transition-all"
                >
                  {copiedId === office.id ? <Check size={14} /> : <Copy size={14} />}
                  {copiedId === office.id ? 'Copied!' : 'Copy Link'}
                </button>
                <a 
                  href={`/register/${office.id}`}
                  target="_blank"
                  className="p-2.5 bg-neutral-100 text-neutral-600 rounded-xl hover:bg-neutral-200 transition-all"
                >
                  <ExternalLink size={18} />
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6">
          <div className="bg-white rounded-3xl w-full max-w-md p-8 animate-in fade-in zoom-in duration-200">
            <h2 className="text-2xl font-bold text-neutral-900 mb-6">Add New Office</h2>
            <form onSubmit={handleAddOffice} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-neutral-700">Office Name</label>
                <input 
                  required
                  value={newOffice.name}
                  onChange={(e) => setNewOffice({...newOffice, name: e.target.value})}
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  placeholder="e.g. Central Branch"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-neutral-700">City</label>
                <input 
                  required
                  value={newOffice.city}
                  onChange={(e) => setNewOffice({...newOffice, city: e.target.value})}
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  placeholder="e.g. Cairo"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-neutral-700">Subscription Expiry</label>
                <input 
                  required
                  type="date"
                  value={newOffice.expiry}
                  onChange={(e) => setNewOffice({...newOffice, expiry: e.target.value})}
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 px-4 py-3 bg-neutral-100 text-neutral-600 rounded-xl font-bold hover:bg-neutral-200 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-4 py-3 bg-primary text-white rounded-xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all"
                >
                  Create Office
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
