import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, getDocs } from 'firebase/firestore';
import { db, auth, storage } from '../firebase';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  Users, 
  FileText, 
  TrendingUp, 
  DollarSign, 
  AlertCircle,
  Building2,
  Calendar
} from 'lucide-react';
import { cn } from '../lib/utils';

export default function ReportsPage() {
  const [stats, setStats] = useState({
    totalCustomers: 0,
    activePolicies: 0,
    expiredPolicies: 0,
    adminProfit: 0,
    officeCommission: 0,
    unpaidCustomers: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const customersSnap = await getDocs(collection(db, 'customers'));
      const policiesSnap = await getDocs(collection(db, 'policies'));

      const customers = customersSnap.docs.map(doc => doc.data());
      const policies = policiesSnap.docs.map(doc => doc.data());

      const totalCustomers = customers.length;
      const activePolicies = policies.filter(p => p.status === 'active').length;
      const expiredPolicies = policies.filter(p => p.status === 'expired').length;
      const adminProfit = policies.reduce((acc, p) => acc + (p.admin_profit || 0), 0);
      const officeCommission = policies.reduce((acc, p) => acc + (p.office_commission || 0), 0);
      const unpaidCustomers = customers.filter(c => c.payment_status === 'unpaid').length;

      setStats({
        totalCustomers,
        activePolicies,
        expiredPolicies,
        adminProfit,
        officeCommission,
        unpaidCustomers,
      });
      setLoading(false);
    };

    fetchData();
  }, []);

  const data = [
    { name: 'Active', value: stats.activePolicies, color: '#10b981' },
    { name: 'Expired', value: stats.expiredPolicies, color: '#ef4444' },
  ];

  const profitData = [
    { name: 'Admin Profit', amount: stats.adminProfit },
    { name: 'Office Commission', amount: stats.officeCommission },
  ];

  return (
    <div className="space-y-10">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Reports & Analytics</h1>
        <p className="text-neutral-500 mt-1">Overview of system performance and financial metrics.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
        <StatCard title="Total Customers" value={stats.totalCustomers} icon={Users} color="bg-blue-500" />
        <StatCard title="Active Policies" value={stats.activePolicies} icon={FileText} color="bg-green-500" />
        <StatCard title="Expired Policies" value={stats.expiredPolicies} icon={AlertCircle} color="bg-red-500" />
        <StatCard title="Admin Profit" value={`$${stats.adminProfit.toLocaleString()}`} icon={TrendingUp} color="bg-primary" />
        <StatCard title="Office Profits" value={`$${stats.officeCommission.toLocaleString()}`} icon={Building2} color="bg-orange-500" />
        <StatCard title="Unpaid" value={stats.unpaidCustomers} icon={DollarSign} color="bg-red-600" />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Policy Status Chart */}
        <div className="bg-white p-8 rounded-3xl border border-neutral-200 shadow-sm">
          <h3 className="text-xl font-bold text-neutral-900 mb-6">Policy Status Distribution</h3>
          <div style={{ width: "100%", height: 300 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-8 mt-4">
            {data.map(item => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm font-semibold text-neutral-600">{item.name}: {item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Profit Comparison Chart */}
        <div className="bg-white p-8 rounded-3xl border border-neutral-200 shadow-sm">
          <h3 className="text-xl font-bold text-neutral-900 mb-6">Profit vs Commission</h3>
          <div style={{ width: "100%", height: 300 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={profitData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} />
                <Tooltip cursor={{ fill: '#f9fafb' }} />
                <Bar dataKey="amount" fill="#141414" radius={[8, 8, 0, 0]} barSize={60} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color }: any) {
  return (
    <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-all">
      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white mb-4", color)}>
        <Icon size={20} />
      </div>
      <div>
        <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest mb-1">{title}</p>
        <p className="text-2xl font-bold text-neutral-900 tracking-tight">{value}</p>
      </div>
    </div>
  );
}
