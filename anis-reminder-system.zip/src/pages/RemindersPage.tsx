import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, getDoc, updateDoc, where } from 'firebase/firestore';
import { db, auth, storage } from '../firebase';
import { 
  Bell, 
  Send, 
  CheckCircle2, 
  XCircle, 
  RefreshCw,
  MessageCircle,
  Calendar,
  User,
  Car,
  AlertTriangle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format, differenceInDays } from 'date-fns';

interface Reminder {
  id: string;
  customer_id: string;
  customer_name?: string;
  customer_phone?: string;
  customer_whatsapp?: string;
  vehicle_info?: string;
  expiry_date: any;
  status: string;
  policy_id?: string;
  vehicle_id?: string;
  type: 'Insurance' | 'Stamp' | 'Inspection' | 'Policy';
  created_at?: any;
}

export default function RemindersPage() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Listen to Policies
    const qPolicies = query(collection(db, 'policies'), where('status', '==', 'active'));
    const unsubscribePolicies = onSnapshot(qPolicies, async (snapshot) => {
      const policyData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      processReminders(policyData, 'policies');
    });

    // 2. Listen to Vehicles
    const qVehicles = query(collection(db, 'vehicles'));
    const unsubscribeVehicles = onSnapshot(qVehicles, async (snapshot) => {
      const vehicleData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      processReminders(vehicleData, 'vehicles');
    });

    return () => {
      unsubscribePolicies();
      unsubscribeVehicles();
    };
  }, []);

  const processReminders = async (data: any[], source: 'policies' | 'vehicles') => {
    setLoading(true);
    const remindersList: Reminder[] = [];
    
    for (const item of data) {
      const checkExpiry = (date: any, type: Reminder['type'], vehicleData?: any) => {
        if (!date) return;
        const expiryDate = date.toDate ? date.toDate() : new Date(date);
        const daysLeft = differenceInDays(expiryDate, new Date());
        
        if (daysLeft <= 10 && daysLeft >= 0) {
          return { expiryDate, daysLeft, type };
        }
      };

      if (source === 'policies') {
        const expiry = checkExpiry(item.expiry_date, 'Policy');
        if (expiry && item.vehicle_id) {
          const vehicleDoc = await getDoc(doc(db, 'vehicles', item.vehicle_id));
          if (vehicleDoc.exists()) {
            const vData = vehicleDoc.data();
            if (vData.customer_id) {
              const customerDoc = await getDoc(doc(db, 'customers', vData.customer_id));
              if (customerDoc.exists()) {
              const cData = customerDoc.data();
              remindersList.push({
                id: item.id,
                customer_id: vData.customer_id,
                customer_name: cData.name,
                customer_phone: cData.phone,
                customer_whatsapp: cData.whatsapp,
                vehicle_info: `${vData.brand} ${vData.model} (${vData.plate_number})`,
                expiry_date: item.expiry_date,
                status: cData.status || 'Active',
                policy_id: item.id,
                type: 'Policy',
                created_at: cData.created_at
              });
            }
          }
        }
      }
    } else {
      // Check vehicle document expiries
        const docTypes: { key: string, label: Reminder['type'] }[] = [
          { key: 'insurance_expiry', label: 'Insurance' },
          { key: 'stamp_expiry', label: 'Stamp' },
          { key: 'inspection_expiry', label: 'Inspection' }
        ];

        for (const docType of docTypes) {
          const expiry = checkExpiry(item[docType.key], docType.label);
          if (expiry && item.customer_id) {
            const customerDoc = await getDoc(doc(db, 'customers', item.customer_id));
            if (customerDoc.exists()) {
              const cData = customerDoc.data();
              remindersList.push({
                id: `${item.id}-${docType.key}`,
                customer_id: item.customer_id,
                customer_name: cData.name,
                customer_phone: cData.phone,
                customer_whatsapp: cData.whatsapp,
                vehicle_info: `${item.brand} ${item.model} (${item.plate_number})`,
                expiry_date: item[docType.key],
                status: cData.status || 'Active',
                vehicle_id: item.id,
                type: docType.label,
                created_at: cData.created_at
              });
            }
          }
        }
      }
    }

    setReminders(prev => {
      // Merge and remove duplicates by ID
      const combined = [...prev, ...remindersList];
      const unique = Array.from(new Map(combined.map(r => [r.id, r])).values());
      // Sort by expiry date
      return unique.sort((a, b) => {
        const dateA = a.expiry_date.toDate ? a.expiry_date.toDate() : new Date(a.expiry_date);
        const dateB = b.expiry_date.toDate ? b.expiry_date.toDate() : new Date(b.expiry_date);
        return dateA.getTime() - dateB.getTime();
      });
    });
    setLoading(false);
  };

  const updateStatus = async (reminder: Reminder, newStatus: string) => {
    if (!reminder.customer_id) return;
    try {
      await updateDoc(doc(db, 'customers', reminder.customer_id), { status: newStatus });
      if (newStatus === 'تم التجديد' && reminder.policy_id) {
        await updateDoc(doc(db, 'policies', reminder.policy_id), { status: 'renewed' });
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const sendWhatsApp = (reminder: Reminder) => {
    const date = format(reminder.expiry_date.toDate ? reminder.expiry_date.toDate() : new Date(reminder.expiry_date), 'MMM dd, yyyy');
    const customerWhatsApp = reminder.customer_whatsapp || reminder.customer_phone || '';
    const formattedCustomerNum = customerWhatsApp.startsWith('00') ? customerWhatsApp : `00218${customerWhatsApp.replace(/^0/, '')}`;
    
    // 1. Message for Customer
    const customerMessage = `مرحباً ${reminder.customer_name}، نود تذكيركم بأن وثيقة (${reminder.type}) لسيارتكم (${reminder.vehicle_info}) ستنتهي بتاريخ ${date}. هل ترغبون في التجديد؟`;
    const customerUrl = `https://wa.me/${formattedCustomerNum}?text=${encodeURIComponent(customerMessage)}`;
    window.open(customerUrl, '_blank');

    // 2. Message for Admin
    const adminNum = "00218911288166";
    const createdAt = reminder.created_at?.toDate ? format(reminder.created_at.toDate(), 'yyyy-MM-dd') : 'N/A';
    const adminMessage = `اسم العميل: ${reminder.customer_name}\nتاريخ التسجيل: ${createdAt}\nرقم الواتساب: ${customerWhatsApp}\nنوع الوثيقة: ${reminder.type}\nستنتهي بعد 7 أيام (${date})`;
    const adminUrl = `https://wa.me/${adminNum}?text=${encodeURIComponent(adminMessage)}`;
    
    setTimeout(() => {
      window.open(adminUrl, '_blank');
    }, 1000);
  };

  const send7DayAdminReminders = () => {
    const sevenDayReminders = reminders.filter(r => {
      const expiryDate = r.expiry_date.toDate ? r.expiry_date.toDate() : new Date(r.expiry_date);
      const daysLeft = differenceInDays(expiryDate, new Date());
      return daysLeft === 7;
    });

    if (sevenDayReminders.length === 0) {
      alert('No documents are expiring in exactly 7 days.');
      return;
    }

    sevenDayReminders.forEach((reminder, index) => {
      setTimeout(() => {
        const date = format(reminder.expiry_date.toDate ? reminder.expiry_date.toDate() : new Date(reminder.expiry_date), 'MMM dd, yyyy');
        const adminNum = "00218911288166";
        const createdAt = reminder.created_at?.toDate ? format(reminder.created_at.toDate(), 'yyyy-MM-dd') : 'N/A';
        const adminMessage = `اسم العميل: ${reminder.customer_name}\nتاريخ التسجيل: ${createdAt}\nرقم الواتساب: ${reminder.customer_whatsapp || reminder.customer_phone}\nنوع الوثيقة: ${reminder.type}\nستنتهي بعد 7 أيام (${date})`;
        const adminUrl = `https://wa.me/${adminNum}?text=${encodeURIComponent(adminMessage)}`;
        window.open(adminUrl, '_blank');
      }, index * 1500); // Stagger to avoid pop-up blocking
    });
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight flex items-center gap-3">
            <Bell className="text-primary" size={32} />
            Reminders Panel
          </h1>
          <p className="text-neutral-500 mt-1">Policies and vehicle documents expiring soon.</p>
        </div>
        <button 
          onClick={send7DayAdminReminders}
          className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-xl shadow-lg shadow-red-200 hover:bg-red-700 transition-all font-bold"
        >
          <Send size={20} />
          <span>Send 7-Day Admin Notifications</span>
        </button>
      </div>

      {/* Reminders Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-20 text-neutral-400">Loading reminders...</div>
        ) : reminders.length === 0 ? (
          <div className="col-span-full bg-white border border-neutral-200 rounded-3xl p-12 text-center">
            <div className="w-16 h-16 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 size={32} />
            </div>
            <h3 className="text-xl font-bold text-neutral-900">All caught up!</h3>
            <p className="text-neutral-500 mt-2">No policies are expiring in the next 10 days.</p>
          </div>
        ) : reminders.map((reminder) => {
          const daysLeft = differenceInDays(reminder.expiry_date.toDate(), new Date());
          
          return (
            <div key={reminder.id} className="bg-white rounded-3xl border border-neutral-200 shadow-sm overflow-hidden flex flex-col">
              <div className="p-6 flex-1">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-neutral-100 flex items-center justify-center text-neutral-600 font-bold">
                      {reminder.customer_name?.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-neutral-900">{reminder.customer_name}</h3>
                      <p className="text-sm text-neutral-500 flex items-center gap-1">
                        <Car size={14} />
                        {reminder.vehicle_info}
                      </p>
                    </div>
                  </div>
                  <div className={cn(
                    "px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2",
                    daysLeft <= 3 ? "bg-red-100 text-red-700" : "bg-orange-100 text-orange-700"
                  )}>
                    <AlertTriangle size={14} />
                    {daysLeft} Days Left
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-100">
                    <p className="text-[10px] uppercase tracking-wider font-bold text-neutral-400 mb-1">Expiry Date</p>
                    <p className="text-sm font-semibold text-neutral-700 flex items-center gap-2">
                      <Calendar size={14} className="text-neutral-400" />
                      {format(reminder.expiry_date.toDate(), 'MMM dd, yyyy')}
                    </p>
                  </div>
                  <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-100">
                    <p className="text-[10px] uppercase tracking-wider font-bold text-neutral-400 mb-1">Current Status</p>
                    <p className="text-sm font-semibold text-neutral-700">{reminder.status}</p>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-neutral-50 border-t border-neutral-100 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <button 
                  onClick={() => sendWhatsApp(reminder)}
                  className="flex flex-col items-center justify-center gap-2 p-3 bg-white border border-neutral-200 rounded-2xl hover:bg-green-50 hover:border-green-200 hover:text-green-600 transition-all group"
                >
                  <MessageCircle size={20} className="text-green-500 group-hover:scale-110 transition-transform" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">WhatsApp</span>
                </button>
                <button 
                  onClick={() => updateStatus(reminder, 'تم التواصل')}
                  className="flex flex-col items-center justify-center gap-2 p-3 bg-white border border-neutral-200 rounded-2xl hover:bg-primary/5 hover:border-primary/20 hover:text-primary transition-all"
                >
                  <Send size={20} className="text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Contacted</span>
                </button>
                <button 
                  onClick={() => updateStatus(reminder, 'تم التجديد')}
                  className="flex flex-col items-center justify-center gap-2 p-3 bg-white border border-neutral-200 rounded-2xl hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-all"
                >
                  <RefreshCw size={20} className="text-blue-500" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Renewed</span>
                </button>
                <button 
                  onClick={() => updateStatus(reminder, 'تم الرفض')}
                  className="flex flex-col items-center justify-center gap-2 p-3 bg-white border border-neutral-200 rounded-2xl hover:bg-red-50 hover:border-red-200 hover:text-red-600 transition-all"
                >
                  <XCircle size={20} className="text-red-500" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Rejected</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
