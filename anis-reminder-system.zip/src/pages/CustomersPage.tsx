import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc, getDocs, where, addDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, auth, storage } from '../firebase';
import { 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  Eye, 
  Download, 
  Filter, 
  X,
  MoreVertical,
  ChevronRight,
  MessageCircle,
  Phone,
  Loader2,
  CheckCircle2,
  FileText,
  Bell,
  Camera,
  AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';
import CustomerList from '../components/CustomerList';
import CustomerVehicles from '../components/CustomerVehicles';
import PolicyReminders from '../components/PolicyReminders';
import ExcelImport from '../components/ExcelImport';

interface Customer {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  city: string;
  payment_status: 'paid' | 'unpaid';
  payment_method?: 'cash' | 'electronic';
  status: string;
  customer_notes?: string;
  created_at: any;
  archived: boolean;
}

interface Vehicle {
  id: string;
  customer_id: string;
  car_type: string;
  brand: string;
  model: string;
  year: string;
  plate_number: string;
  chassis_number: string;
  insurance_image_url?: string;
  stamp_image_url?: string;
  inspection_image_url?: string;
}

interface Policy {
  id: string;
  vehicle_id: string;
  price: number;
  office_commission: number;
  admin_profit: number;
  expiry_date: any;
  status: string;
  payment_status: string;
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCity, setFilterCity] = useState('');
  const [filterPayment, setFilterPayment] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isVehiclesModalOpen, setIsVehiclesModalOpen] = useState(false);
  const [isRemindersModalOpen, setIsRemindersModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'customers'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer));
      setCustomers(data);
      setLoading(false);
    }, (error) => {
      console.error('Firestore Error in CustomersPage:', error);
      // Using the required error handling format
      const errInfo = {
        error: error.message,
        operationType: 'get',
        path: 'customers',
        authInfo: {
          userId: auth.currentUser?.uid,
          email: auth.currentUser?.email
        }
      };
      console.error(JSON.stringify(errInfo));
    });
    return unsubscribe;
  }, []);

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         c.phone.includes(searchTerm);
    const matchesCity = filterCity ? c.city === filterCity : true;
    const matchesPayment = filterPayment ? c.payment_status === filterPayment : true;
    return matchesSearch && matchesCity && matchesPayment && !c.archived;
  });

  const cities = Array.from(new Set(customers.map(c => c.city)));

  const exportCSV = () => {
    const headers = ['Name', 'Phone', 'WhatsApp', 'City', 'Payment Status', 'Status'];
    const rows = filteredCustomers.map(c => [
      c.name, c.phone, c.whatsapp, c.city, c.payment_status, c.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + 
      [headers, ...rows].map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "customers_export.csv");
    document.body.appendChild(link);
    link.click();
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 tracking-tight">Customers</h1>
          <p className="text-neutral-500 mt-1">Manage your customer database and interactions.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsRemindersModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-red-600 hover:bg-red-50 transition-all font-medium"
          >
            <Bell size={18} />
            <span>Reminders</span>
          </button>
          <ExcelImport />
          <button 
            onClick={exportCSV}
            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-neutral-600 hover:bg-neutral-50 transition-all font-medium"
          >
            <Download size={18} />
            <span>Export CSV</span>
          </button>
          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-xl shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all font-medium"
          >
            <Plus size={18} />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
          <input
            type="text"
            placeholder="Search by name or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
          />
        </div>
        <div className="flex gap-4">
          <select 
            value={filterCity}
            onChange={(e) => setFilterCity(e.target.value)}
            className="px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none transition-all text-neutral-600"
          >
            <option value="">All Cities</option>
            {cities.map(city => <option key={city} value={city}>{city}</option>)}
          </select>
          <select 
            value={filterPayment}
            onChange={(e) => setFilterPayment(e.target.value)}
            className="px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none transition-all text-neutral-600"
          >
            <option value="">All Payment Status</option>
            <option value="paid">Paid</option>
            <option value="unpaid">Unpaid</option>
          </select>
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
        <div className="p-6">
          <CustomerList 
            onSelectCustomer={(customer) => {
              setSelectedCustomer(customer);
              setIsVehiclesModalOpen(true);
            }} 
            onEditCustomer={(customer) => {
              setSelectedCustomer(customer);
              setIsEditModalOpen(true);
            }}
          />
        </div>
      </div>
      {/* Add Customer Modal */}
      {isAddModalOpen && (
        <AddCustomerModal onClose={() => setIsAddModalOpen(false)} />
      )}

      {/* Edit Customer Modal */}
      {isEditModalOpen && selectedCustomer && (
        <EditCustomerModal 
          customer={selectedCustomer} 
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedCustomer(null);
          }} 
        />
      )}

      {/* Vehicles Modal */}
      {isVehiclesModalOpen && selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col">
            <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/50">
              <div>
                <h2 className="text-2xl font-bold text-neutral-900">Vehicles for {selectedCustomer.name}</h2>
                <p className="text-neutral-500 text-sm">Manage linked vehicles and insurance policies.</p>
              </div>
              <button 
                onClick={() => setIsVehiclesModalOpen(false)}
                className="p-2 hover:bg-neutral-200 rounded-full transition-all"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <CustomerVehicles customerId={selectedCustomer.id} customerName={selectedCustomer.name} />
            </div>
          </div>
        </div>
      )}

      {/* Reminders Modal */}
      {isRemindersModalOpen && (
        <PolicyReminders onClose={() => setIsRemindersModalOpen(false)} />
      )}
    </div>
  );
}

function EditCustomerModal({ customer, onClose }: { customer: Customer, onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    name: customer.name,
    phone: customer.phone,
    whatsapp: customer.whatsapp,
    city: customer.city,
    payment_status: customer.payment_status,
    payment_method: customer.payment_method || 'cash',
    status: customer.status,
    customer_notes: customer.customer_notes || '',
  });

  useEffect(() => {
    const q = query(collection(db, 'vehicles'), where('customer_id', '==', customer.id));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setVehicles(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return unsubscribe;
  }, [customer.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateDoc(doc(db, 'customers', customer.id), formData);
      onClose();
    } catch (error) {
      console.error('Error updating customer:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/50">
          <div>
            <h2 className="text-2xl font-bold text-neutral-900">Edit Customer</h2>
            <p className="text-neutral-500 text-sm">Update customer profile and status.</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-neutral-200 rounded-full transition-all">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 uppercase ml-2">Full Name</label>
              <input
                required
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 uppercase ml-2">Phone</label>
              <input
                required
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 uppercase ml-2">WhatsApp</label>
              <input
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.whatsapp}
                onChange={e => setFormData({...formData, whatsapp: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 uppercase ml-2">City</label>
              <input
                required
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.city}
                onChange={e => setFormData({...formData, city: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 uppercase ml-2">Payment Status</label>
              <select
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.payment_status}
                onChange={e => setFormData({...formData, payment_status: e.target.value as any})}
              >
                <option value="unpaid">Unpaid</option>
                <option value="paid">Paid</option>
              </select>
            </div>
            {formData.payment_status === 'paid' && (
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 uppercase ml-2">Payment Method</label>
                <select
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  value={formData.payment_method}
                  onChange={e => setFormData({...formData, payment_method: e.target.value as any})}
                >
                  <option value="cash">Cash</option>
                  <option value="electronic">Electronic</option>
                </select>
              </div>
            )}
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-400 uppercase ml-2">Customer Status</label>
            <select
              className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
              value={formData.status}
              onChange={e => setFormData({...formData, status: e.target.value})}
            >
              <option value="تم التواصل">Contacted</option>
              <option value="تم الرد">Replied</option>
              <option value="تم التجديد">Renewed</option>
              <option value="لم يتم الرد">No Reply</option>
              <option value="تم الرفض">Rejected</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-400 uppercase ml-2">Notes</label>
            <textarea
              className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20 min-h-[100px]"
              value={formData.customer_notes}
              onChange={e => setFormData({...formData, customer_notes: e.target.value})}
            />
          </div>

          <button
            disabled={loading}
            className="w-full py-4 bg-primary text-white rounded-2xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" /> : <CheckCircle2 />}
            <span>Save Changes</span>
          </button>
        </form>
      </div>
    </div>
  );
}

function AddCustomerModal({ onClose }: { onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [files, setFiles] = useState<{ [key: string]: File | null }>({
    insurance: null,
    stamp: null,
    inspection: null
  });
  const [formData, setFormData] = useState({
    // Customer
    name: '',
    phone: '',
    whatsapp: '',
    city: '',
    // Vehicle
    car_type: 'Private',
    brand: '',
    model: '',
    year: new Date().getFullYear().toString(),
    plate_number: '',
    chassis_number: '',
    // Expiry Dates
    insurance_expiry: format(new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
    stamp_expiry: format(new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
    inspection_expiry: format(new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
    // Policy
    price: '',
    expiry_date: format(new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
  });

  const uploadFile = async (file: File, type: string, vehicleId: string) => {
    const fileName = `${vehicleId}_${file.name}`;
    const storageRef = ref(storage, `${type}/${fileName}`);
    await uploadBytes(storageRef, file);
    return await getDownloadURL(storageRef);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (!files.insurance || !files.stamp || !files.inspection) {
      setError('Please upload all required documents (Insurance, Stamp, and Inspection).');
      setLoading(false);
      return;
    }

    try {
      // 1. Create Customer
      const customerRef = await addDoc(collection(db, 'customers'), {
        name: formData.name,
        phone: formData.phone,
        whatsapp: formData.whatsapp,
        city: formData.city,
        payment_status: 'unpaid',
        status: 'جديد',
        archived: false,
        created_at: serverTimestamp()
      });

      // 2. Create Vehicle
      const vehicleRef = await addDoc(collection(db, 'vehicles'), {
        customer_id: customerRef.id,
        car_type: formData.car_type,
        brand: formData.brand,
        model: formData.model,
        year: formData.year,
        plate_number: formData.plate_number,
        chassis_number: formData.chassis_number,
        insurance_expiry: Timestamp.fromDate(new Date(formData.insurance_expiry)),
        stamp_expiry: Timestamp.fromDate(new Date(formData.stamp_expiry)),
        inspection_expiry: Timestamp.fromDate(new Date(formData.inspection_expiry)),
        created_at: serverTimestamp()
      });

      // 3. Upload Images
      const insuranceUrl = await uploadFile(files.insurance, 'insurance', vehicleRef.id);
      const stampUrl = await uploadFile(files.stamp, 'stamp', vehicleRef.id);
      const inspectionUrl = await uploadFile(files.inspection, 'inspection', vehicleRef.id);

      // 4. Update Vehicle with URLs
      await updateDoc(doc(db, 'vehicles', vehicleRef.id), {
        insurance_image_url: insuranceUrl,
        stamp_image_url: stampUrl,
        inspection_image_url: inspectionUrl
      });

      // 5. Create Policy
      await addDoc(collection(db, 'policies'), {
        vehicle_id: vehicleRef.id,
        price: parseFloat(formData.price) || 0,
        office_commission: 0,
        admin_profit: 0,
        expiry_date: Timestamp.fromDate(new Date(formData.expiry_date)),
        status: 'active',
        payment_status: 'unpaid',
        created_at: serverTimestamp()
      });

      onClose();
    } catch (error: any) {
      console.error('Error adding customer system:', error);
      setError(error.message || 'Failed to create record. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/50">
          <div>
            <h2 className="text-2xl font-bold text-neutral-900">Add New Customer System</h2>
            <p className="text-neutral-500 text-sm">Create customer, vehicle, and policy records at once.</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-neutral-200 rounded-full transition-all">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-8">
          {error && (
            <div className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-xl flex items-center gap-3 text-sm">
              <AlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}
          {/* Customer Info */}
          <section className="space-y-4">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px]">1</span>
              Customer Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input
                required
                placeholder="Full Name"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
              <input
                required
                placeholder="Phone Number"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
              />
              <input
                placeholder="WhatsApp (Optional)"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.whatsapp}
                onChange={e => setFormData({...formData, whatsapp: e.target.value})}
              />
              <input
                required
                placeholder="City"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.city}
                onChange={e => setFormData({...formData, city: e.target.value})}
              />
            </div>
          </section>

          {/* Vehicle Info */}
          <section className="space-y-4">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px]">2</span>
              Vehicle Details
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <select
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.car_type}
                onChange={e => setFormData({...formData, car_type: e.target.value})}
              >
                <option value="Private">Private</option>
                <option value="Taxi">Taxi</option>
                <option value="Truck">Truck</option>
                <option value="Motorcycle">Motorcycle</option>
              </select>
              <input
                required
                placeholder="Brand (e.g. Toyota)"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.brand}
                onChange={e => setFormData({...formData, brand: e.target.value})}
              />
              <input
                required
                placeholder="Model (e.g. Camry)"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.model}
                onChange={e => setFormData({...formData, model: e.target.value})}
              />
              <input
                required
                placeholder="Year"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.year}
                onChange={e => setFormData({...formData, year: e.target.value})}
              />
              <input
                required
                placeholder="Plate Number"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.plate_number}
                onChange={e => setFormData({...formData, plate_number: e.target.value})}
              />
              <input
                required
                placeholder="Chassis Number"
                className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                value={formData.chassis_number}
                onChange={e => setFormData({...formData, chassis_number: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-2">Insurance Expiry</label>
                <input
                  required
                  type="date"
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  value={formData.insurance_expiry}
                  onChange={e => setFormData({...formData, insurance_expiry: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-2">Stamp Expiry</label>
                <input
                  required
                  type="date"
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  value={formData.stamp_expiry}
                  onChange={e => setFormData({...formData, stamp_expiry: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-2">Inspection Expiry</label>
                <input
                  required
                  type="date"
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  value={formData.inspection_expiry}
                  onChange={e => setFormData({...formData, inspection_expiry: e.target.value})}
                />
              </div>
            </div>
          </section>

          {/* Document Info */}
          <section className="space-y-4">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px]">3</span>
              Documents
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <FileInput 
                label="Insurance Document" 
                file={files.insurance} 
                onChange={(e: any) => setFiles({...files, insurance: e.target.files[0]})} 
              />
              <FileInput 
                label="Stamp Document" 
                file={files.stamp} 
                onChange={(e: any) => setFiles({...files, stamp: e.target.files[0]})} 
              />
              <FileInput 
                label="Inspection Document" 
                file={files.inspection} 
                onChange={(e: any) => setFiles({...files, inspection: e.target.files[0]})} 
              />
            </div>
          </section>

          {/* Policy Info */}
          <section className="space-y-4">
            <h3 className="text-sm font-bold text-primary uppercase tracking-widest flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px]">4</span>
              Initial Policy
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 font-bold">$</span>
                <input
                  required
                  type="number"
                  placeholder="Policy Price"
                  className="w-full pl-8 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  value={formData.price}
                  onChange={e => setFormData({...formData, price: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-2">Expiry Date</label>
                <input
                  required
                  type="date"
                  className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20"
                  value={formData.expiry_date}
                  onChange={e => setFormData({...formData, expiry_date: e.target.value})}
                />
              </div>
            </div>
          </section>

          <div className="pt-4">
            <button
              disabled={loading}
              className="w-full py-4 bg-primary text-white rounded-2xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" /> : <CheckCircle2 />}
              <span>Create Full Record</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function FileInput({ label, onChange, file }: any) {
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
      return () => URL.revokeObjectURL(url);
    } else {
      setPreview(null);
    }
  }, [file]);

  return (
    <div className="space-y-2">
      <label className="text-[10px] font-bold text-neutral-400 uppercase ml-2">{label}</label>
      <div className="relative group">
        <input 
          type="file" 
          accept="image/*"
          capture="environment"
          onChange={onChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        <div className={cn(
          "w-full h-24 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-all overflow-hidden",
          file ? "border-green-200 bg-green-50" : "border-neutral-200 bg-neutral-50 group-hover:border-primary/30"
        )}>
          {preview ? (
            <img src={preview} alt="Preview" className="w-full h-full object-cover" />
          ) : (
            <div className="flex flex-col items-center gap-1">
              <Camera size={20} className="text-neutral-400" />
              <span className="text-[8px] font-bold text-neutral-500 uppercase">Take Photo</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PoliciesList({ vehicleId, customerPhone, customerName }: { vehicleId: string, customerPhone: string, customerName: string }) {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'policies'), where('vehicle_id', '==', vehicleId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Policy));
      setPolicies(data);
      setLoading(false);
    });
    return unsubscribe;
  }, [vehicleId]);

  const sendReminder = async (policy: Policy) => {
    const date = format(policy.expiry_date?.toDate ? policy.expiry_date.toDate() : new Date(policy.expiry_date?.seconds * 1000), 'MMM dd, yyyy');
    const customerWhatsApp = customerPhone || '';
    const formattedCustomerNum = customerWhatsApp.startsWith('00') ? customerWhatsApp : `00218${customerWhatsApp.replace(/^0/, '')}`;
    
    // 1. Message for Customer
    const customerMessage = `مرحباً، نود تذكيركم بأن وثيقة التأمين لسيارتكم ستنتهي بتاريخ ${date}. هل ترغبون في التجديد؟`;
    const customerUrl = `https://wa.me/${formattedCustomerNum}?text=${encodeURIComponent(customerMessage)}`;
    window.open(customerUrl, '_blank');

    // 2. Message for Admin
    const adminNum = "00218911288166";
    const adminMessage = `اسم العميل: ${customerName}\nرقم الواتساب: ${customerWhatsApp}\nنوع الوثيقة: Insurance Policy\nستنتهي بتاريخ (${date})`;
    const adminUrl = `https://wa.me/${adminNum}?text=${encodeURIComponent(adminMessage)}`;
    
    setTimeout(() => {
      window.open(adminUrl, '_blank');
    }, 1000);
    
    // Update status to 'reminded'
    if (!policy.id) return;
    try {
      await updateDoc(doc(db, 'policies', policy.id), {
        status: 'reminded'
      });
    } catch (error) {
      console.error('Error updating policy status:', error);
    }
  };

  if (loading) return <div className="text-xs text-neutral-400">Loading policies...</div>;
  if (policies.length === 0) return <div className="text-xs text-neutral-400 italic">No policies found for this vehicle.</div>;

  return (
    <div className="space-y-3">
      {policies.map(policy => (
        <div key={policy.id} className="flex items-center justify-between p-4 bg-neutral-50 rounded-xl border border-neutral-100 group hover:border-primary/20 transition-all">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 flex-1">
            <div>
              <p className="text-[10px] font-bold text-neutral-400 uppercase">Price</p>
              <p className="text-sm font-bold text-neutral-900">${policy.price}</p>
            </div>
            <div>
              <p className="text-[10px] font-bold text-neutral-400 uppercase">Expiry Date</p>
              <p className="text-sm text-neutral-700">
                {policy.expiry_date?.seconds 
                  ? new Date(policy.expiry_date.seconds * 1000).toLocaleDateString() 
                  : 'N/A'}
              </p>
            </div>
            <div>
              <p className="text-[10px] font-bold text-neutral-400 uppercase">Status</p>
              <span className={cn(
                "text-[10px] font-bold uppercase px-2 py-0.5 rounded",
                policy.status === 'active' ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
              )}>
                {policy.status}
              </span>
            </div>
            <div>
              <p className="text-[10px] font-bold text-neutral-400 uppercase">Payment</p>
              <span className={cn(
                "text-[10px] font-bold uppercase px-2 py-0.5 rounded",
                policy.payment_status === 'paid' ? "bg-blue-100 text-blue-700" : "bg-red-100 text-red-700"
              )}>
                {policy.payment_status}
              </span>
            </div>
          </div>
          <button 
            onClick={() => sendReminder(policy)}
            className="ml-4 p-2.5 bg-white border border-neutral-200 rounded-xl text-primary hover:bg-primary hover:text-white transition-all shadow-sm"
            title="Send WhatsApp Reminder"
          >
            <MessageCircle size={18} />
          </button>
        </div>
      ))}
    </div>
  );
}
